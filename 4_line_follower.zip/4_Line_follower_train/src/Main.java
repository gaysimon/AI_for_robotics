import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;



public class Main {

	public static String PATH="Path/to/project/files";	// path to dataset and image
	
	public static int size_x=31;	// size of the image (set when image is loaded)
	public static int size_y=31;
	
	public float[][] matrixImages;
	public int[] matrixLabels;
	public int nbTests;
	
	public int epoch=0;
	public int test=0;
	
	public static int nb_values=10;		// number of classes
	
	//-----------------
	private DisplayFrame display;		// display panel
	
	//-----------------
	public Layer layer;				// Neuron Layer
	
	//////////////
	public Main(){
		
		// initialize display frame
		display=new DisplayFrame(this);

	
		// write network
		/*try {
			PrintWriter file  = new PrintWriter(new FileWriter(PATH+"network.txt"));
			
			for (int n=0;n<layer.weights.length;n++){	
				// save neurons parameters
				for (int i=0;i<layer.weights[n].length;i++){
					file.print(layer.weights[n][i]+" ");
				}
				file.println();
			}
			file.close();
			System.out.println("Network saved");
		}
		catch (Exception e) {e.printStackTrace();}
		*/
	}
	
	
	// function to load dataset file into a matrix and a vector of labels
	public void setData(String fileImg){
		try {
			
			InputStreamReader ipsr=new InputStreamReader(new FileInputStream(PATH+ fileImg));
			BufferedReader br=new BufferedReader(ipsr);
			
			String l;
			l=br.readLine();
			
			int nb=0;
			// count dataset elements
			while (l!=null){
				nb++;
				l=br.readLine();
			}
			
			System.out.println("dataset contains "+nb*2+" elements");
			
			matrixImages=new float[nb*2][size_x*size_y];
			matrixLabels=new int[nb*2];
			
			br.close();
			
			ipsr=new InputStreamReader(new FileInputStream(PATH+ fileImg));
			br=new BufferedReader(ipsr);
			
			l=br.readLine();
			String[] elements;
			System.out.println(l);
			
			nb=0;
			while (l!=null){
				
				// main parameters
				elements=l.split(" ");
				for (int i=0;i<size_x;i++){
					for (int j=0;j<size_y;j++){
						matrixImages[nb][i*size_y+j]=(float)(255-Integer.parseInt(elements[i*size_y+j]))/255f;
					}
				}
				
				int value=Integer.parseInt(elements[elements.length-1]);
				
				// convert directions into labels
				if (value<=5) matrixLabels[nb]=0;
				if (value>= 6 && value<= 8) matrixLabels[nb]=1;
				if (value>= 9 && value<=10) matrixLabels[nb]=2;
				if (value>=11 && value<=12) matrixLabels[nb]=3;
				if (value>=13 && value<=14) matrixLabels[nb]=4;
				if (value==15) matrixLabels[nb]=5;
				if (value>=16 && value<=17) matrixLabels[nb]=6;
				if (value>=18 && value<=19) matrixLabels[nb]=7;
				if (value>=20 && value<=21) matrixLabels[nb]=8;
				if (value>=22 && value<=24) matrixLabels[nb]=9;
				if (value>=25) matrixLabels[nb]=10;
				nb++;
				
				
				
				// mirror images to increase dataset's content
				for (int i=0;i<size_x;i++){
					for (int j=0;j<size_y;j++){
						matrixImages[nb][i*size_y+(size_y-1-j)]=(float)(255-Integer.parseInt(elements[i*size_y+j]))/255f;
					}
				}
				
				value=30-Integer.parseInt(elements[elements.length-1]);
				if (value<=5) matrixLabels[nb]=0;
				if (value>= 6 && value<= 8) matrixLabels[nb]=1;
				if (value>= 9 && value<=10) matrixLabels[nb]=2;
				if (value>=11 && value<=12) matrixLabels[nb]=3;
				if (value>=13 && value<=14) matrixLabels[nb]=4;
				if (value==15) matrixLabels[nb]=5;
				if (value>=16 && value<=17) matrixLabels[nb]=6;
				if (value>=18 && value<=19) matrixLabels[nb]=7;
				if (value>=20 && value<=21) matrixLabels[nb]=8;
				if (value>=22 && value<=24) matrixLabels[nb]=9;
				if (value>=25) matrixLabels[nb]=10;
				nb++;
				
				
				l=br.readLine();
			}
			br.close();
	        
		
		} catch (IOException e) {System.out.print(e);}
	}
	
	
	
	/////////////////////////////////////////////////////
	// main function
	public static void main(String[] args) {
		
		new Main();
		
	}

}
