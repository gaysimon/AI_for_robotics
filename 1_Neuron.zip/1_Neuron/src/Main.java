import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;



public class Main {

	public static String PATH="PATH_TO_DATASETS/MNIST/numbers/";	// path to images
	
	public static int size_x=28;	// size of the image (set when image is loaded
	public static int size_y=28;
	
	public float[][] matrixImages;
	public int[] matrixLabels;
	public int nbTests;
	
	public int epoch=0;
	public int test=0;
	
	public static int number=3;			// selected digit for test
	
	//-----------------
	private DisplayFrame display;		// display panel
	
	
	//-----------------
	public Neuron neuron;				// single neuron
	
	
	
	//////////////
	public Main(){
		
		// initialize structures
		neuron=new Neuron();
		
		// load test matrix
		setData("train-images.idx3-ubyte","train-labels.idx1-ubyte");
		
		// initialize display frame
		display=new DisplayFrame(this);
		

		// TODO : learning
		
		
		System.out.println("learning completed");
		
		
		///////////////////////////////////////////////////////
		// evaluation of the neuron
		int errors=0;
		
		// load evaluation dataset
		setData("t10k-images.idx3-ubyte","t10k-labels.idx1-ubyte");
		
		
		
		// TODO : evaluation
		
		
		
		// display number of errors
		//System.out.println("total "+errors+" errors");
		
		display.repaint();
	}
	
	
	// function to load datasets
	public void setData(String fileImg, String fileLabels){
		try {
			// open file containing images
			System.out.println("open "+PATH+fileImg);
			DataInputStream dataFile = new DataInputStream(
												new BufferedInputStream(
												   new FileInputStream(PATH+fileImg)));
			
			// read property numbers
			int magicNumber = dataFile.readInt();
	        int nbImages = dataFile.readInt();
	        size_y = dataFile.readInt();
	        size_x = dataFile.readInt();

	        System.out.println("magic number is " + magicNumber);
	        System.out.println("number of items is " + nbImages);
	        System.out.println("number of rows is: " + size_y);
	        System.out.println("number of cols is: " + size_x);
	        
	        // initialize the image matrix
	        int nbPixels=size_x*size_y;
	        matrixImages=new float[nbImages][nbPixels];
	        
	        // write images in the matrix (one image per matrix line)
	        for (int i=0;i<nbImages;i++){
	        	for (int j=0;j<nbPixels;j++){
	        		matrixImages[i][j]=((float)dataFile.readUnsignedByte())/255;
	        	}
	        }
	        
	        // close the image file
	        dataFile.close();
	        
	        // open file containing results
			DataInputStream labelFile = new DataInputStream(
												new BufferedInputStream(
												   new FileInputStream(PATH+fileLabels)));
			
			// read property numbers
			int labelMagicNumber = labelFile.readInt();
		    nbTests = labelFile.readInt();
	
		    System.out.println("labels magic number is: " + labelMagicNumber);
		    System.out.println("number of labels is: " + nbTests);
		
		    matrixLabels=new int[nbTests];
		    for (int i=0;i<nbTests;i++){
		    	matrixLabels[i]=labelFile.readUnsignedByte();
		    }
		    labelFile.close();
		
		} catch (IOException e) {System.out.print(e);}
	}
	
	
	
	/////////////////////////////////////////////////////
	// main function
	public static void main(String[] args) {
		
		new Main();
		
	}

}
